ICC ODI Batting Database Query Tool

Team Members: 
Satyam Jaiswal, Chandan Maurya

Overview
The "ODI Batting Database Query Tool" is a Python-based application designed to interact with a MySQL database containing comprehensive datasets related to cricket. The GUI interface provides users with intuitive controls to explore different aspects of cricket data, including player details, batting statistics, ICC rankings, and leaderboard information. This README offers detailed instructions on running the application, understanding its functionalities, and exploring the underlying code structure.

Prerequisites
- Python 3.x installed on your system.
- MySQL database server installed and running.

Usage 
1. Running the Application:
- Execute the Python script `DTSC_Final_Project.ipynb` in your preferred Python environment.

2. Selecting Database:
- Upon launching the application, users can select a database option from the dropdown menu:
- Player Details: Retrieve and display comprehensive player details from the database.
- Batting Stats: Select a player's name to view their batting statistics, including matches played, runs scored, average, and strike rate.
- ICC Ranking: Choose from various ICC ranking queries to explore rankings, averages, strike rates, and highest individual scores.
- Leaderboard: Select a specific category (e.g., most centuries, fifties, sixes, etc.) to view the player with the highest count in that category.

3. Exploring Data:
- Depending on the selected database, users can explore data using the following functionalities:
- Player Details: Retrieve and display all player details from the database.
- Batting Stats: Select a player's name from the dropdown menu to view their batting statistics.
- ICC Ranking: Choose from predefined ranking queries to explore rankings and player data.
- Leaderboard: Select a specific category (e.g., most centuries, fifties, sixes, etc.) to view the corresponding player with the highest count.

Key Functionalities and Functions Overview
1. Database Interaction:
- The application interacts with the MySQL database to execute queries and fetch data based on user selections.
- Functions such as `execute_custom_query()` and `execute_selected_query()` handle database connections and query executions.

2. GUI Interface:
- The GUI interface presents users with dropdown menus, radio buttons, and buttons to navigate through different database options and functionalities.
- Functions like `create_main_window()` and `open_query_window()` manage the creation and layout of GUI components.

3. Error Handling:
- Error handling mechanisms are implemented to manage database connection errors, query execution errors, and user input validation.
- Functions such as `display_result()` and `display_player_stats()` incorporate error checking and exception handling to ensure smooth operation.

Execution
Upon selecting a database and exploring data within the GUI, the application fetches and displays relevant information from the MySQL database. Users can view details such as player names, batting statistics, ICC rankings, and leaderboard information, providing valuable insights into cricket data.

Example
An example usage scenario within the GUI might involve selecting the "Leaderboard" database option, followed by choosing the "Player with the most Number of Sixes" query. The application would then display the player with the highest number of sixes, along with their country information.
